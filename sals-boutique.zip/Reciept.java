import java.util.ArrayList;
public class Reciept
{
    ArrayList x = new ArrayList();
    public void addPrice(int value, String item)
    {
        x.add(value);
        x.add(item);
    }
    public int findTotal()
    {
        int sum=0;
        for(int i=0;i<x.size();i=i+2)
        {
            sum = sum + (int)x.get(i);
        }
    return sum;
    }
    public void printReciept()
    {
        System.out.println();
        System.out.println();
        System.out.println("Your receipt at Sal's Boutique");
        System.out.println("***************************************************************");
 
        for(int i =0; i<x.size(); i=i+2)
        {
            System.out.println(x.get(i+1) + "\t" + x.get(i));
            System.out.println();
        }
        System.out.println("Your total is: " + findTotal() + " AED");
        System.out.println();
        System.out.println("***************************************************************");
        System.out.println("\n Thank you for shopping at Sal's Boutique!");
    }
}