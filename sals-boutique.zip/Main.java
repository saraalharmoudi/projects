import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Reciept r = new Reciept();
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to Sal's Boutique");

int cont = 1;
while (cont == 1) {


    System.out.println("Press 1 if you want to shop for: Formal Attire");
    System.out.println("Press 2 if you want to shop for: Casual Attire");
    System.out.println("Press 3 if you want to shop for: Shoes");

    int catchoice = sc.nextInt();


if (catchoice == 1) {

    System.out.println("\nYou are shopping for Formal Attire at Sal's Boutique");
    System.out.println("\nChoose what type of Formal Attire you'd like by pressing the following numbers: \n1. Gowns \n2. Skirts \n3. Emirati Thob (Exclusive Collection)");

    int formalchoice = sc.nextInt();

    if (formalchoice == 1) {

        System.out.println("\nThese are the colors of gowns available, choose the one to your liking by pressing the gown's number: \nRed Dress #21 for AED 2398 \nBlack Dress #36 for AED 2398 \nPink Dress #45 for AED 2398");
        int gownchoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(2398, "Gown");

    } else if (formalchoice == 2) {

        System.out.println("\nThese are the colors of skirts available, choose the one to your liking by pressing the skirt's number: \nWhite Skirt #56 for AED 215 \nBeige Skirt #78 for AED 215 \nBrown Skirt #16 for AED 215");
        int skirtchoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(215, "Skirt");

    } else if (formalchoice == 3) {

        System.out.println("\nThese are the colors of Emirati Thobs available, choose the one to your liking by pressing the thob's number: \nPurple Thob #2 for AED 1971 \nBlue Thob #12 for AED 1971 \nGreen Thob #71 for AED 1971");
        int thobchoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(1971, "Emirati Thob");

    }

}


else if (catchoice == 2) {

    System.out.println("\nYou are shopping for Casual Attire at Sal's Boutique");
    System.out.println("\nChoose what type of Casual Attire you'd like by pressing the following numbers: \n1. Shirts \n2. Sweaters \n3. Trousers");

    int casualchoice = sc.nextInt();

    if (casualchoice == 1) {

        System.out.println("\nThese are the types of shirts available, choose the one to your liking by pressing the shirt's number: \nGraphic Shirt #44 for AED 116 \nOversized Shirt #93 for AED 116 \nFitted Shirt #89 for AED 116");
        int shirtchoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(116, "Shirt");

    } else if (casualchoice == 2) {

        System.out.println("\nThese are the colors of sweaters available, choose the one to your liking by pressing the sweater's number: \nNavy Sweater #31 for AED 320 \nGrey Sweater #24 for AED 320 \nBurgundy Sweater #53 for AED 320");
        int sweaterchoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(320, "Sweater");

    } else if (casualchoice == 3) {

        System.out.println("\nThese are the colors of Trousers available, choose the one to your liking by pressing the trouser's number: \nMaroon #66 for AED 297 \nKhaki #5 for AED 297 \nOlive Green #7 for AED 297");
        int trouserschoice = sc.nextInt();
        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(297, "Trousers");

    }

}


else if (catchoice == 3) {

    System.out.println("\nYou are shopping for Shoes at Sal's Boutique");

    System.out.println("\nChoose what type of Shoes you'd like by pressing the following numbers: \n1. Heels \n2. Flats");

    int shoeschoice = sc.nextInt();

    if (shoeschoice == 1) {

        System.out.println("\nThese are the heights of heels available, choose the one to your liking by pressing the heel's number: \n3 inch #8 for AED 728 \n4 inch #52 for AED 728 \n5 inch #10 for AED 728");

        int heelschoice = sc.nextInt();

        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(728, "Heels");

    } else if (shoeschoice == 2) {

        System.out.println("\nThese are the types of Flats available, choose the one to your liking by pressing the flat's number: \nBallet Flats #81 for AED 580 \nOpen-toed Flats #22 for AED 580 \nLoafers #35 for AED 580");

        int flatschoice = sc.nextInt();

        System.out.println("\nThe item has been successfully added to your cart");

        r.addPrice(580, "Flats");

    }

} else {

    System.out.println("Unavailable, Try again");

}


System.out.println();

System.out.println("Would you like to continue shopping?\nIf yes press 1\nIf no press 2");

cont = sc.nextInt();

        }

        r.printReciept();

    }

}