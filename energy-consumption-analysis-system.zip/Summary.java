public class Summary {
    private int[] energy;
    private int[] renewable;

    public Summary(int[] energy, int[] renewable) {
        this.energy = energy;
        this.renewable = renewable;
    }

    public void display() {
        System.out.println("\n----- Energy Consumption Summary -----");
        System.out.println("Total Years Analyzed: " + energy.length);

        System.out.println("Average Energy Consumption: " + getAvg(energy) + " GJ");
        System.out.println("Average Renewable Energy Usage: " + getAvg(renewable) + "%");

        System.out.println("\nSearching for optimal renewable energy usage (above 70%)...");
        if (searchValue(renewable, 70)) {
            System.out.println("At least one year had renewable energy above 70%.");
        } else {
            System.out.println("No year had renewable energy above 70%.");
        }

        System.out.println("\n----- Sustainability Assessment -----");
        sustainability();
    }

    private double getAvg(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return (double) sum / arr.length;
    }

    private boolean searchValue(int[] arr, int target) {
        for (int num : arr) {
            if (num >= target) {
                return true; // Found a value above or equal to the threshold
            }
        }
        return false; // Not found
    }

    private void sustainability() {
        double avgEnergy = getAvg(energy);
        double avgRenewable = getAvg(renewable);

        if (avgEnergy <= 80 && avgRenewable >= 70) {
            System.out.println("Sustainable: The country's energy use is within limits and relies heavily on renewables.");
        } else if (avgEnergy > 80 && avgEnergy <= 150 && avgRenewable >= 50) {
            System.out.println("Moderate: The country is making progress but could improve efficiency or renewable share.");
        } else {
            System.out.println("Unsustainable: High energy consumption and/or low renewable energy use.");
        }
    }
}
