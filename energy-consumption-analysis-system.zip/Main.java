/// APCSA T2 PROJECT - SARA H.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("ABU DHABI DEPARTMENT OF ENERGY");

        boolean contAnalysis = true;

        while (contAnalysis) {
            System.out.println("\nPlease log in with your Username");
            String user = sc.nextLine();
            
            System.out.println("Welcome back, " + user.toUpperCase()); // Using a string method
            
            System.out.println("\nHow many years would you like to analyze the energy consumption for?");
            int year = sc.nextInt();
            
            int[] energy = new int[year];
            int[] renewable = new int[year];

            for (int i = 0; i < year; i++) { 
                System.out.print("\nEnter the energy consumption for year " + (i + 1) + " in Gigajoules: ");
                energy[i] = sc.nextInt();
                
                System.out.print("\nEnter the percentage of renewable energy used in year " + (i + 1) + " (don't use '%'): ");
                renewable[i] = sc.nextInt();
            }

            // Create an instance of Summary and call its methods
            Summary summary = new Summary(energy, renewable);
            summary.display();

            // Ask the user if they want to analyze another set of data
            System.out.println("\nWould you like to analyze another set of years? (yes/no)");
            sc.nextLine(); // Consume newline left after nextInt()
            String response = sc.nextLine();

            if (!response.equals("yes")) {
                contAnalysis = false;
                System.out.println("\nYou have successfully completed an Energy Analysis via The Energy Consumption System developed by The ABU DHABI DEPARTMENT OF ENERGY");
            }
        }
    }
}
