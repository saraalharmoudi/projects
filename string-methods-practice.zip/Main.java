import java.util.Scanner;

public class Main {

    public static int getStringLength(String str) {
        return str.length();
    }

    public static String toUpperCase(String str) {
        return str.toUpperCase();
    }

    public static String toLowerCase(String str) {
        return str.toLowerCase();
    }

    public static String getSubstringFromIndex(String str, int index) {
        if (index >= 0 && index < str.length()) {
            return str.substring(index);
        } else {
            return "Invalid index!";
        }
    }

    public static int getIndexOfCharacter(String str, char ch) {
        return str.indexOf(ch);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String original = scanner.nextLine();

        System.out.print("Enter another string: ");
        String another = scanner.nextLine();

        System.out.println("\n--- String Operations ---");
        System.out.println("Length of original string: " + getStringLength(original));
        System.out.println("Uppercase: " + toUpperCase(original));
        System.out.println("Lowercase: " + toLowerCase(another));

        System.out.print("\nEnter an index to get substring from original: ");
        int index = scanner.nextInt();
        System.out.println("Substring: " + getSubstringFromIndex(original, index));

        System.out.print("\nEnter a character to find its position in original string: ");
        char ch = scanner.next().charAt(0);
        int pos = getIndexOfCharacter(original, ch);
        if (pos != -1) {
            System.out.println("First occurrence of '" + ch + "': " + pos);
        } else {
            System.out.println("Character not found.");
        }

        // Extra: Comparing the two strings
        int comparison = original.compareTo(another);
        System.out.println("\nComparison result (original vs another): " + comparison);

        // Explaining compareTo vs indexOf
        System.out.println("\n--- Early Finisher Bonus ---");
        System.out.println("indexOf() gives the position of a character or substring.");
        System.out.println("compareTo() compares two strings alphabetically.");

        scanner.close();
    }
}