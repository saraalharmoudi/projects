import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your GPA: ");
        double gpa = scanner.nextDouble();

        System.out.println("Enter your SAT score: ");
        int satScore = scanner.nextInt();

        String[] universities = {"Khalifa University", "UAE University", "Zayed University"};
        double[] minGPAs = {3.5, 3.0, 3.2};
        int[] minSATScores = {1400, 1200, 1300};
        String[] globalRankings = {"#10 in the world", "#20 in the world", "#30 in the world"};

        System.out.println("Universities you are eligible for based on your GPA and SAT score:");
        for (int i = 0; i < universities.length; i++) {
            if (gpa >= minGPAs[i] && satScore >= minSATScores[i]) {
                System.out.println(universities[i] + " - Global Ranking: " + globalRankings[i]);
                System.out.println("Minimum GPA Requirement: " + minGPAs[i]);
                System.out.println("Minimum SAT Score Requirement: " + minSATScores[i]);
                System.out.println("---------------------------");
            }
        }
    }
}