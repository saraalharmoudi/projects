import java.util.ArrayList;
import java.util.Scanner;

class Task {
    private String description;

    public Task(String desc) {
        description = desc;
    }

    public String getDescription() {
        return description;
    }

    public String toString() {
        return "- " + description;
    }
}

public class ToDoApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Task> tasks = new ArrayList<>();
        int choice;

        do {
            System.out.println("\n To-Do List Menu");
            System.out.println("1. Add a task");
            System.out.println("2. View tasks");
            System.out.println("3. Remove a task");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine(); 

            if (choice == 1) {
                System.out.print("Enter task description: ");
                String desc = input.nextLine();
                tasks.add(new Task(desc));
                System.out.println("Task added!");
            } else if (choice == 2) {
                if (tasks.isEmpty()) {
                    System.out.println("No tasks yet!");
                } else {
                    System.out.println("Your tasks:");
                    for (int i = 0; i < tasks.size(); i++) {
                        System.out.println((i + 1) + ". " + tasks.get(i));
                    }
                }
            } else if (choice == 3) {
                if (tasks.isEmpty()) {
                    System.out.println("Nothing to remove!");
                } else {
                    System.out.print("Enter task number to remove: ");
                    int num = input.nextInt();
                    input.nextLine(); 
                    if (num >= 1 && num <= tasks.size()) {
                        tasks.remove(num - 1);
                        System.out.println("Task removed!");
                    } else {
                        System.out.println("Invalid task number.");
                    }
                }
            } else if (choice == 4) {
                System.out.println("Goodbye!");
            } else {
                System.out.println("Invalid option. Try again.");
            }

        } while (choice != 4);

        input.close();
    }
}
