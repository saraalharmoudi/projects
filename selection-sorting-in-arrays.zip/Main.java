public class Main
{
	public static void main(String[] args) {
	int min , temp;
	int [] num = {30,10,40,50,20};
		
		for(int i=0; i<num.length-1; i++)	{
		min=num[i];
		
		for(int j=i+1; j<num.length; j++)	{
		    if(num[j]<min)
		    min=j;
		}
		
		temp=num[i];
		num[i]=num[min];
		num[min]=temp;
		
		}
		
		for (int a: num)
		System.out.println(a);
	}
}
